# RRRRMarkdown
Code demos for _Reproducible Research and Reports with R Markdown_, a video course with O'Reilly Media.
